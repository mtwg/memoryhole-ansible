<?php
// created: 2014-12-11 18:41:41
$dictionary["legal_events"]["fields"]["legal_events_legal_witnesses"] = array (
  'name' => 'legal_events_legal_witnesses',
  'type' => 'link',
  'relationship' => 'legal_events_legal_witnesses',
  'source' => 'non-db',
  'module' => 'legal_witnesses',
  'bean_name' => false,
  'vname' => 'LBL_LEGAL_EVENTS_LEGAL_WITNESSES_FROM_LEGAL_WITNESSES_TITLE',
);
