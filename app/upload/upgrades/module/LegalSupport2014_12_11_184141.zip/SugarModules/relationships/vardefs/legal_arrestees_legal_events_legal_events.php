<?php
// created: 2014-12-11 18:41:41
$dictionary["legal_events"]["fields"]["legal_arrestees_legal_events"] = array (
  'name' => 'legal_arrestees_legal_events',
  'type' => 'link',
  'relationship' => 'legal_arrestees_legal_events',
  'source' => 'non-db',
  'module' => 'legal_arrestees',
  'bean_name' => false,
  'vname' => 'LBL_LEGAL_ARRESTEES_LEGAL_EVENTS_FROM_LEGAL_ARRESTEES_TITLE',
);
