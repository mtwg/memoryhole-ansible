<?php
// created: 2014-12-11 18:41:41
$dictionary["legal_evidence"]["fields"]["legal_arrestees_legal_evidence"] = array (
  'name' => 'legal_arrestees_legal_evidence',
  'type' => 'link',
  'relationship' => 'legal_arrestees_legal_evidence',
  'source' => 'non-db',
  'module' => 'legal_arrestees',
  'bean_name' => false,
  'vname' => 'LBL_LEGAL_ARRESTEES_LEGAL_EVIDENCE_FROM_LEGAL_ARRESTEES_TITLE',
);
