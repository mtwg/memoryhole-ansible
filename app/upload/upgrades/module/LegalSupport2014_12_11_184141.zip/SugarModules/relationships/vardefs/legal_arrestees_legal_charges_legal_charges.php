<?php
// created: 2014-12-11 18:41:41
$dictionary["legal_charges"]["fields"]["legal_arrestees_legal_charges"] = array (
  'name' => 'legal_arrestees_legal_charges',
  'type' => 'link',
  'relationship' => 'legal_arrestees_legal_charges',
  'source' => 'non-db',
  'module' => 'legal_arrestees',
  'bean_name' => false,
  'vname' => 'LBL_LEGAL_ARRESTEES_LEGAL_CHARGES_FROM_LEGAL_ARRESTEES_TITLE',
);
