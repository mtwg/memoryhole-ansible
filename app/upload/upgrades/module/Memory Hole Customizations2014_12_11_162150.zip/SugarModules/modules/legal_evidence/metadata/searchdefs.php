<?php
$module_name = 'legal_evidence';
$searchdefs = array (
$module_name =>
array (
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'width' => '50',
      ),
      'evidence_id_c' => 
      array (
        'label' => 'LBL_EVIDENCE_ID',
        'width' => '10',
        'name' => 'evidence_id_c',
        'default_value' => '',
      ),
      'datetimelocation_c' => 
      array (
        'label' => 'LBL_DATETIMELOCATION',
        'width' => '10',
        'name' => 'datetimelocation_c',
        'default_value' => '',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
      ),
      'type' => 
      array (
        'label' => 'LBL_TYPE',
        'width' => '10',
        'name' => 'type',
      ),
      'witness' => 
      array (
        'label' => 'LBL_WITNESS',
        'width' => '10',
        'name' => 'witness',
      ),
      'evidence_id_c' => 
      array (
        'label' => 'LBL_EVIDENCE_ID',
        'width' => '10',
        'name' => 'evidence_id_c',
        'default_value' => '',
      ),
      'description' => 
      array (
        'label' => 'LBL_DESCRIPTION',
        'width' => '10',
        'name' => 'description',
      ),
      'date_entered' => 
      array (
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10',
        'name' => 'date_entered',
      ),
      'modified_by_name' => 
      array (
        'label' => 'LBL_MODIFIED_NAME',
        'width' => '10',
        'name' => 'modified_by_name',
      ),
      'date_modified' => 
      array (
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10',
        'name' => 'date_modified',
      ),
      'created_by_name' => 
      array (
        'label' => 'LBL_CREATED',
        'width' => '10',
        'name' => 'created_by_name',
      ),
      'datetimelocation_c' => 
      array (
        'label' => 'LBL_DATETIMELOCATION',
        'width' => '10',
        'name' => 'datetimelocation_c',
        'default_value' => '',
      ),
    ),
  ),
)
);
?>
