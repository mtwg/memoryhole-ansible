<?php
// created: 2008-08-22 21:45:58
$mod_strings = array (
  'value' => 'Use of_Force',
  'LBL_EVIDENCE_ID' => 'Evidence ID',
  'LBL_IDENTIFIER' => 'EvidenceID',
  'LBL_ID_DISPLAY' => 'EvidenceID',
  'LBL_WITNESS' => 'Submitter',
  'LBL_NAME' => 'Title',
  'LBL_DATETIMELOCATION' => 'Date/Time/Locations',
  'LBL_USE_OF_FORCE' => 'Use of Force',
);
?>
