<?php
$module_name = 'legal_evidence';
$listViewDefs = array (
$module_name =>
array (
  'NAME' => 
  array (
    'width' => '32',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'EVIDENCE_ID_C' => 
  array (
    'width' => '10',
    'label' => 'LBL_EVIDENCE_ID',
    'sortable' => false,
    'default' => true,
  ),
  'TYPE' => 
  array (
    'width' => '10',
    'label' => 'LBL_TYPE',
    'sortable' => false,
    'default' => true,
  ),
  'WITNESS' => 
  array (
    'width' => '10',
    'label' => 'LBL_WITNESS',
    'default' => true,
  ),
  'DATE_MODIFIED' => 
  array (
    'width' => '10',
    'label' => 'LBL_DATE_MODIFIED',
    'default' => true,
  ),
  'CREATED_BY_NAME' => 
  array (
    'width' => '10',
    'label' => 'LBL_CREATED',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'width' => '10',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'width' => '10',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'width' => '10',
    'label' => 'LBL_MODIFIED_NAME',
    'default' => false,
  ),
)
);
?>
