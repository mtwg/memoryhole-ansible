<?php
// created: 2008-10-29 19:34:28
$mod_strings = array (
  'value' => 'Mass Arrest',
  'LBL_USE_OF_FORCE' => 'Police Misconduct',
  'LBL_MASS_ARREST' => 'Mass Arrest',
);
?>
