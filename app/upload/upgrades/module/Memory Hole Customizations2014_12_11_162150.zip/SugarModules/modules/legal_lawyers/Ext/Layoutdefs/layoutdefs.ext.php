<?php 
 //WARNING: The contents of this file are auto-generated


//auto-generated file DO NOT EDIT
$layout_defs['legal_lawyers']['subpanel_setup']['legal_arrestees']['override_subpanel_name'] = 'legal_lawyersdefault';

?>