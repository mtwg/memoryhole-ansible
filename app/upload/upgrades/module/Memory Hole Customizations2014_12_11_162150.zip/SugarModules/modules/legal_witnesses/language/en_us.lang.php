<?php
// created: 2008-06-11 03:50:37
$mod_strings = array (
  'LBL_MOBILE_PHONE' => 'Phone 1',
  'LBL_OFFICE_PHONE' => 'Phone 2',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Street Address',
  'LBL_DESCRIPTION' => 'Notes',
  'value' => 'State',
  'LBL_STATE' => 'State',
);
?>
