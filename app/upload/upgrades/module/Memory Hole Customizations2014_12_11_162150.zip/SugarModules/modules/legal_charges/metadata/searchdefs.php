<?php
$module_name = 'legal_charges';
$searchdefs = array (
$module_name =>
array (
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
      ),
      'charge' => 
      array (
        'label' => 'LBL_CHARGE',
        'width' => '10',
        'name' => 'charge',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
      ),
      'charge' => 
      array (
        'label' => 'LBL_CHARGE',
        'width' => '10',
        'name' => 'charge',
      ),
      'created_by_name' => 
      array (
        'label' => 'LBL_CREATED',
        'width' => '10',
        'name' => 'created_by_name',
      ),
      'date_entered' => 
      array (
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10',
        'name' => 'date_entered',
      ),
      'date_modified' => 
      array (
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10',
        'name' => 'date_modified',
      ),
      'modified_by_name' => 
      array (
        'label' => 'LBL_MODIFIED_NAME',
        'width' => '10',
        'name' => 'modified_by_name',
      ),
      'description' => 
      array (
        'label' => 'LBL_DESCRIPTION',
        'width' => '10',
        'name' => 'description',
      ),
    ),
  ),
)
);
?>
