<?php
$module_name = 'legal_charges';
$listViewDefs = array (
$module_name =>
array (
  'NAME' => 
  array (
    'width' => '32',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'CHARGE' => 
  array (
    'width' => '10',
    'label' => 'LBL_CHARGE',
    'default' => true,
  ),
  'DATE_MODIFIED' => 
  array (
    'width' => '10',
    'label' => 'LBL_DATE_MODIFIED',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'width' => '10',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
  ),
)
);
?>
