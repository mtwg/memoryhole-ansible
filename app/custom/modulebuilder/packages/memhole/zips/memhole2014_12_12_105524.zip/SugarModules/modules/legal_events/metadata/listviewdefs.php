<?php
$module_name = 'legal_events';
$listViewDefs = array (
$module_name =>
array (
  'NAME' => 
  array (
    'width' => '32',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'LOCTATION' => 
  array (
    'width' => '10',
    'label' => 'LBL_LOCTATION',
    'default' => true,
  ),
  'DATE' => 
  array (
    'width' => '10',
    'label' => 'LBL_DATE',
    'default' => true,
  ),
  'START_TIME' => 
  array (
    'width' => '10',
    'label' => 'LBL_START_TIME',
    'default' => true,
  ),
  'END_TIME' => 
  array (
    'width' => '10',
    'label' => 'LBL_END_TIME',
    'default' => true,
  ),
  'USE_OF_FORCE' => 
  array (
    'width' => '10',
    'label' => 'LBL_USE_OF_FORCE',
    'default' => false,
  ),
)
);
?>
