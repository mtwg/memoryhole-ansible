<?php
// created: 2011-12-29 14:48:55
$mod_strings = array (
  'value' => 'NLG',
  'LBL_ORGANIZATION' => 'Organization',
  'LBL_NLG' => 'NLG',
  'LBL_MOBILE_PHONE' => 'Phone 1',
  'LBL_OFFICE_PHONE' => 'Phone 2',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Street Address',
  'LBL_DESCRIPTION' => 'Notes',
  'LBL_STATE' => 'State',
  'LBL_LAWYER_ROLES' => 'Lawyer Roles',
  'LBL_LAWYERSSPECIALTIES' => 'Lawyer Specialties',
  'LBL_LICENSE_NUMBER' => 'License Number',
  'LBL_PRACTICING_STATES' => 'Practicing States',
  'LBL_YEARS_IN_PRACTICE' => 'Years In_Practice',
  'LBL_YEARS_IN_CRIM_PRACTICE' => 'Years In_Crim_Practice',
  'LBL_CAN_REPRESENT_IN_MN' => 'Can Represent_in_MN',
  'LBL_FEDERAL_PRACTICE' => 'Federal Practice?',
  'LBL_REPRESENTED_PROTESTORS' => 'Represented Protestors?',
  'LBL_CIVIL_RIGHTS_EXPERIENCE' => 'Civil Rights Experience?',
  'LBL_REGULAR_COURTS' => 'Regular Courts',
  'LBL_PUBLIC_DEFENDER' => 'Public Defender',
);
?>
